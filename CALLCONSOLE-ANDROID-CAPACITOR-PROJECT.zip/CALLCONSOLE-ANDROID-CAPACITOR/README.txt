CALLCONSOLE — ANDROID CAPACITOR PACKAGE

This package is prepared from CALLCONSOLE V24 Offline App Foundation.

WHAT IS READY
- The full CALLCONSOLE web app in www/
- Offline PWA files
- Capacitor configuration
- Android app ID: com.epmsolutions.callconsole
- App name: CALLCONSOLE
- Native packaging scripts

TO GENERATE THE ANDROID PROJECT AND APK
1. Install Node.js (already present in many developer environments).
2. Install Android Studio with Android SDK.
3. In this folder run:
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android

4. In Android Studio:
   Build > Build Bundle(s) / APK(s) > Build APK(s)

The generated APK can then be installed on an Android phone.

WHY THE APK IS NOT INCLUDED YET
A final APK requires the Android SDK/Gradle build environment and the Capacitor Android package.
This prepared project keeps the existing CALLCONSOLE code intact and is ready for that native build step.

IMPORTANT
All CALLCONSOLE core logic remains offline-first. Any future online research features can be optional.
