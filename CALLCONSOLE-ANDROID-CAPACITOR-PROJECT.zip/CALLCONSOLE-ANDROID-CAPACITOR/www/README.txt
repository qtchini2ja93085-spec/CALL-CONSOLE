CALLCONSOLE V24 — OFFLINE APP FOUNDATION

WHAT THIS PACKAGE DOES
- Keeps the existing CALLCONSOLE V23 app as the core.
- Adds an installable Progressive Web App (PWA) layer.
- Adds offline caching through a service worker.
- Adds app metadata and icons for installation.

IMPORTANT
A PWA must be served from HTTPS or localhost for the service worker and Install App behavior to work.
Opening index.html directly with file:// will not enable the service worker.

NEXT PACKAGING PATH
1. Test the PWA in Chrome/Edge using localhost or HTTPS.
2. Package the same web app for Android with Capacitor.
3. Package the same web app for Windows with Tauri.

OFFLINE-FIRST
Once the app is loaded and cached from a valid PWA host, the core app can reopen without an internet connection.
